/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gameweb;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author bo-gu
 */
public class AdminLoginController implements Initializable {
    
    @FXML
    private MenuItem logoutButton;
    @FXML
    private MenuButton menuBottonAccount;
    @FXML
    private MenuItem myAccount;
    @FXML
    private Button customerInfo;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    


    private void cartclicked(MouseEvent event) throws IOException {
       Stage stage=new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(root);
        Stage register= (Stage) ((Node) event.getSource()).getScene().getWindow(); 
        register.setScene(scene);
        register.show();
    }

    @FXML
    private void logoutClicked(ActionEvent event) throws IOException {
        Stage stage=new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        Scene scene = new Scene(root);
        Stage register= (Stage) ((Node)menuBottonAccount).getScene().getWindow(); 
        register.setScene(scene);
        register.show();
    }
   

    private void contactUsClicked(ActionEvent event) {
         Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Contact Us");
                    alert.setHeaderText(null);
                    alert.setContentText("Feel free to contact our support team if you have ANY question."
                            + " \n\n Phone: 123-444-5555 \n Email: gsu@gmail.com");
                    alert.showAndWait();
        
    }

    @FXML
    private void myAccountClicked(ActionEvent event) throws IOException {
        
         Stage stage=new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("myaccount.fxml"));
        Scene scene = new Scene(root);
        Stage register= (Stage) ((Node)menuBottonAccount).getScene().getWindow(); 
        register.setScene(scene);
        register.show();
        
    }

    @FXML
    private void customerInfoClicked(ActionEvent event) throws IOException {
         Stage stage=new Stage();
        Parent root = FXMLLoader.load(getClass().getResource("customerInfo.fxml"));
        Scene scene = new Scene(root);
        Stage register= (Stage) ((Node)menuBottonAccount).getScene().getWindow(); 
        register.setScene(scene);
        register.show();
        
        
    }



}
